<body>
    <link rel="stylesheet" href="../../css/pdf.css">

    <div class="container pm-certificate-container">
        <div class="outer-border"></div>
        <div class="inner-border"></div>

        <div class="pm-certificate-border col-xs-12">
            <div class="row pm-certificate-header">
                <div class="pm-certificate-title col-xs-12 text-center">
                    <h2>GYANMANJARI INSTITUTE OF TECHNOLOGY</h2>
                </div>
                <div class="pm-certificate-title cursive col-xs-12 text-center">
                    <h2>Provisional Certificate Verification</h2>
                </div>
            </div>

            <div class="row pm-certificate-body">

                <div class="pm-certificate-block">
                    <div class="col-xs-12">
                        <div class="row">
                            <div class="pm-credits-text block bold sans">This is to certify that</div>
                            <br>
                            <div class="pm-certificate-name underline margin-0 col-xs-8 text-center">
                                <span class="pm-name-text bold"></span>
                            </div>
                            <br>
                            <div class="pm-credits-text block bold sans">Enrollment No.
                                <span class="col-md-2 kp-empty-space block underline"></span>
                                <div class="pj-credits-text block bold sans">of Branch
                                    <span class="col-md-2 pj-empty-space block underline"></span>
                                    <br>
                                    <div class="pk-credits-text block bold sans"> has satisfactory completed his / her term work as prescribed in syllabus and within the
                                    </div>
                                    <br>
                                    <div class="pc-credits-text block bold sans">premises of <b>GYANMANJARI INSTITUTE OF TECHNOLOGY</b> , Bhavnagar .
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</body>